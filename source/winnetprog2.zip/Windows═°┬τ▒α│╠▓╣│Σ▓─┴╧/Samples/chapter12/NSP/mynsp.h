#ifndef _MY_NSP_H_
#define _MY_NSP_H_

extern GUID MY_NAMESPACE_GUID;

#define NS_MYNSP	66

#define MYNSP_SUCCESS    1
#define MYNSP_ERROR      0

#endif
