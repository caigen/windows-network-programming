The vbrcvall sample demonstrates the usage of Winsock 2 raw socket and new Win2000 ioctl code SIO_RCVALL, SIO_RCVALL_MCAST, and SIO_RCVALL_IGMPMCAST, to capture IP packets, mutlicast packets, and IGMP packets.

This sample only runs on Win2000.
