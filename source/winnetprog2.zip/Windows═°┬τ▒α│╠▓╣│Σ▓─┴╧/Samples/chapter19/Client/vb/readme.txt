The client sample demonstrate writing a message to a mailslot.

The application doesn't have a user interface. It uses VB message box to indicate program status to users.
