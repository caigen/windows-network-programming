The server sample demonstrates creating a mailslot and receiving a message from the mailslot.

The application doesn't have a user interface. It uses VB message box to indicate program status to users. If there is no mailslot client writing to the mailslot, the server app will not exit. In this case, you need to use the task manager to kill the server.
